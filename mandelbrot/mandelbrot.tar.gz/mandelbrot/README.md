#
create and save an image of mandelbrot set with some different colors.
#
#
usage: gcc mandelbrot.cpp pbm.c -o mandel
            ./mandel
#
